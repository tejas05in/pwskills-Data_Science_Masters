from setuptools import find_packages, setup

setup(
    name="Cat-Dog",
    version="0.0.1",
    author="iNeuron",
    author_email="query@ineuron.ai",
    packages=find_packages(),
    install_requires=[],
)