# YOLO web app


315865595366.dkr.ecr.us-east-1.amazonaws.com/yoloapp

